// Load cart when page loads
document.addEventListener('DOMContentLoaded', () => {
    loadCart();
    updateCartCount();
    checkAuth();
});

// Load cart items
async function loadCart() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];

    if (cart.length === 0) {
        document.getElementById('empty-cart').style.display = 'block';
        document.getElementById('cart-summary').style.display = 'none';
        return;
    }

    const cartItemsContainer = document.getElementById('cart-items');
    cartItemsContainer.innerHTML = '';

    let subtotal = 0;

    for (const item of cart) {
        try {
            const response = await fetch(`${API_URL}/products/${item.productId}`);
            const product = await response.json();

            const itemTotal = product.price * item.quantity;
            subtotal += itemTotal;

            cartItemsContainer.innerHTML += `
                <div class="cart-item">
                    <img src="${product.image}" alt="${product.name}" class="cart-item-image">
                    <div class="cart-item-details">
                        <h3 class="cart-item-name">${product.name}</h3>
                        <p class="cart-item-price">$${product.price.toFixed(2)}</p>
                    </div>
                    <div class="cart-item-quantity">
                        <button class="qty-btn" onclick="updateQuantity('${item.productId}', ${item.quantity - 1})">-</button>
                        <input type="number" value="${item.quantity}" min="1" max="${product.stock}" 
                               onchange="updateQuantity('${item.productId}', this.value)" class="qty-input">
                        <button class="qty-btn" onclick="updateQuantity('${item.productId}', ${item.quantity + 1})">+</button>
                    </div>
                    <div class="cart-item-total">
                        <p class="item-total">$${itemTotal.toFixed(2)}</p>
                        <button class="btn btn-danger btn-small" onclick="removeFromCart('${item.productId}')">Remove</button>
                    </div>
                </div>
            `;
        } catch (error) {
            console.error('Error loading cart item:', error);
        }
    }

    // Update summary
    const total = subtotal + 10; // Add shipping
    document.getElementById('subtotal').textContent = `$${subtotal.toFixed(2)}`;
    document.getElementById('total').textContent = `$${total.toFixed(2)}`;
    document.getElementById('cart-summary').style.display = 'block';
}

// Update item quantity
function updateQuantity(productId, newQuantity) {
    newQuantity = parseInt(newQuantity);

    if (newQuantity < 1) {
        removeFromCart(productId);
        return;
    }

    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    const item = cart.find(i => i.productId === productId);

    if (item) {
        item.quantity = newQuantity;
        localStorage.setItem('cart', JSON.stringify(cart));
        loadCart();
        updateCartCount();
    }
}

// Remove item from cart
function removeFromCart(productId) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart = cart.filter(item => item.productId !== productId);
    localStorage.setItem('cart', JSON.stringify(cart));
    loadCart();
    updateCartCount();
}

// Proceed to checkout
function proceedToCheckout() {
    const user = JSON.parse(localStorage.getItem('user'));

    if (!user) {
        alert('Please login to proceed to checkout');
        window.location.href = 'login.html';
        return;
    }

    window.location.href = 'checkout.html';
}