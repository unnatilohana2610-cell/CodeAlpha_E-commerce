const API_URL = 'http://localhost:5000/api';

// Load products when page loads
document.addEventListener('DOMContentLoaded', () => {
    loadProducts();
    updateCartCount();
    checkAuth();
});

// Load all products
async function loadProducts() {
    try {
        const response = await fetch(`${API_URL}/products`);
        const products = await response.json();

        const loading = document.getElementById('loading');
        const container = document.getElementById('products-container');

        loading.style.display = 'none';

        if (products.length === 0) {
            container.innerHTML = '<p>No products available.</p>';
            return;
        }

        container.innerHTML = products.map(product => `
            <div class="product-card" onclick="viewProduct('${product._id}')">
                <img src="${product.image}" alt="${product.name}" class="product-image">
                <div class="product-info">
                    <h3 class="product-name">${product.name}</h3>
                    <p class="product-description">${product.description}</p>
                    <p class="product-price">$${product.price.toFixed(2)}</p>
                    <p class="product-rating">⭐ ${product.rating} / 5</p>
                    <button class="btn btn-primary" onclick="event.stopPropagation(); addToCart('${product._id}')">
                        Add to Cart
                    </button>
                </div>
            </div>
        `).join('');

    } catch (error) {
        console.error('Error loading products:', error);
        document.getElementById('loading').innerHTML = 'Error loading products. Please try again.';
    }
}

// View product details
function viewProduct(productId) {
    window.location.href = `product.html?id=${productId}`;
}

// Add product to cart
function addToCart(productId) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];

    const existingItem = cart.find(item => item.productId === productId);

    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({ productId, quantity: 1 });
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    alert('Product added to cart!');
}

// Update cart count in navbar
function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    const cartCount = document.getElementById('cart-count');
    if (cartCount) {
        cartCount.textContent = totalItems;
    }
}

// Check if user is logged in
function checkAuth() {
    const user = JSON.parse(localStorage.getItem('user'));
    const authLink = document.getElementById('auth-link');

    if (authLink) {
        if (user) {
            authLink.textContent = 'Logout';
            authLink.href = '#';
            authLink.onclick = logout;
        } else {
            authLink.textContent = 'Login';
            authLink.href = 'login.html';
        }
    }
}

// Logout function
function logout() {
    localStorage.removeItem('user');
    localStorage.removeItem('token');
    window.location.href = 'index.html';
}