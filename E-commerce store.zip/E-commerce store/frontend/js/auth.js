// Handle user registration
async function handleRegister(event) {
    event.preventDefault();

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm-password').value;
    const errorMessage = document.getElementById('error-message');

    // Clear previous errors
    errorMessage.textContent = '';

    // Validate passwords match
    if (password !== confirmPassword) {
        errorMessage.textContent = 'Passwords do not match!';
        return;
    }

    try {
        const response = await fetch(`${API_URL}/users/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name, email, password })
        });

        const data = await response.json();

        if (response.ok) {
            // Save user data and token
            localStorage.setItem('user', JSON.stringify(data));
            localStorage.setItem('token', data.token);

            alert('Registration successful!');
            window.location.href = 'index.html';
        } else {
            errorMessage.textContent = data.message || 'Registration failed. Please try again.';
        }
    } catch (error) {
        console.error('Registration error:', error);
        errorMessage.textContent = 'An error occurred. Please try again.';
    }
}

// Handle user login
async function handleLogin(event) {
    event.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const errorMessage = document.getElementById('error-message');

    // Clear previous errors
    errorMessage.textContent = '';

    try {
        const response = await fetch(`${API_URL}/users/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password })
        });

        const data = await response.json();

        if (response.ok) {
            // Save user data and token
            localStorage.setItem('user', JSON.stringify(data));
            localStorage.setItem('token', data.token);

            alert('Login successful!');
            window.location.href = 'index.html';
        } else {
            errorMessage.textContent = data.message || 'Invalid email or password.';
        }
    } catch (error) {
        console.error('Login error:', error);
        errorMessage.textContent = 'An error occurred. Please try again.';
    }
}

// Update cart count on auth pages
document.addEventListener('DOMContentLoaded', () => {
    updateCartCount();
});